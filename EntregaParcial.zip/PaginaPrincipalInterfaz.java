import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Map;

public class PaginaPrincipalInterfaz extends JFrame {

    public PaginaPrincipalInterfaz() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());

        // Crear panel superior para los botones personalizados
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(Color.WHITE);
        JButton boton1 = new JButton("Iniciar Sesión");
        boton1.addActionListener(e -> {
            InterfazLogin login = new InterfazLogin();
            login.setVisible(true);
        });

        JButton boton2 = new JButton("Registrarse");
        boton2.addActionListener(e -> {
            Registro ventanaRegistro = new Registro();
        });
        JButton boton3 = new JButton("Explorar");
        boton3.addActionListener(e -> {
            // Crear instancia entre ventanas
            Map<String, String> imagenes = new HashMap<>();
            imagenes.put("matematicas", "ruta_imagen_matematicas.JPG");
            imagenes.put("historia", "ruta_imagen_historia.JPG");
            imagenes.put("ciencias", "ruta_imagen_ciencias.JPG");
            imagenes.put("geografia", "ruta_imagen_geografia.JPG");

            BuscarYcomentarImagen ventanaNN = new BuscarYcomentarImagen(imagenes);
            ventanaNN.setVisible(true);
        });
        JButton boton4 = new JButton("Acerca de");
        boton1.setForeground(Color.GRAY); // Texto gris
        boton2.setForeground(Color.GRAY);
        boton3.setForeground(Color.GRAY);
        boton4.setForeground(Color.GRAY);
        boton1.setBorderPainted(false); // Quitar borde del botón
        boton2.setBorderPainted(false);
        boton3.setBorderPainted(false);
        boton4.setBorderPainted(false);
        boton1.setBackground(Color.WHITE);
        boton2.setBackground(Color.WHITE);
        boton3.setBackground(Color.WHITE);
        boton4.setBackground(Color.WHITE);
        panelBotones.add(boton1);
        panelBotones.add(boton2);
        panelBotones.add(boton3);
        panelBotones.add(boton4);


        add(panelBotones, BorderLayout.NORTH);

        JPanel panelTitulo = new JPanel(new GridLayout(2, 1));
        panelTitulo.setBackground(Color.WHITE);

        JPanel panelIzquierdo = new JPanel(new GridBagLayout());
        panelIzquierdo.setBackground(Color.WHITE);


        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 0);

        //panel para el título
        JLabel titulo = new JLabel("Aprendizaje Visual");
        titulo.setFont(new Font("Arial", Font.BOLD, 48));
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelIzquierdo.add(titulo, gbc);

        // panel para el subtítulo
        JLabel subtitulo = new JLabel("Descubre herramientas de aprendizaje visual que te ayudarán a aprender mejor y más rápido.");
        panelIzquierdo.add(subtitulo, gbc);

        //panel para el botón "Empieza ya"
        JButton botonExplorar = new JButton("Empieza ya");
        botonExplorar.setForeground(Color.WHITE); // Letras blancas
        botonExplorar.setBackground(Color.YELLOW); // Fondo amarillo
        botonExplorar.setBorderPainted(false); // Quitar borde del botón
        botonExplorar.setFocusPainted(false); // Quitar efecto de enfoque
        botonExplorar.setPreferredSize(new Dimension(100, 30)); // Tamaño cuadrado y chiquito
        panelIzquierdo.add(botonExplorar, gbc);

        add(panelIzquierdo, BorderLayout.CENTER);

        //panel para la imagen
        JPanel panelImagen = new JPanel();
        panelImagen.setBackground(Color.WHITE);
        ImageIcon imagen = new ImageIcon("Vector Gratis.png");
        JLabel etiquetaImagen = new JLabel(imagen);
        panelImagen.add(etiquetaImagen);

        add(panelImagen, BorderLayout.EAST);

        setVisible(true);
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaginaPrincipalInterfaz::new);
    }
}
