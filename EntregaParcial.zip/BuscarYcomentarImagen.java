import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.imageio.ImageIO;

public class BuscarYcomentarImagen extends JFrame {
    private final Map<String, String> imagenes;
    private final File comentariosFile;
    private final JLabel decorativeLabel;

    public BuscarYcomentarImagen (Map<String, String> imagenes) {
        this.imagenes = imagenes;
        this.comentariosFile = new File("comentarios.txt");

        setTitle("Buscador y Comentar Imágenes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);

        setExtendedState(JFrame.MAXIMIZED_BOTH); // Abrir a pantalla completa
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // No cerrar la ventana principal al cerrar esta ventana

        JTextField textField = new JTextField(20);
        JButton buscarButton = new JButton("Buscar");
        JButton comentarButton = new JButton("Comentar");

        JPanel panel = new JPanel(new FlowLayout());
        panel.add(textField);
        panel.add(buscarButton);
        panel.add(comentarButton);

        JTextArea commentArea = new JTextArea(1, 20);
        JScrollPane scrollPane = new JScrollPane(commentArea);
        JPanel imagePanel = new JPanel(new FlowLayout());

        ImageIcon decorativeImage = new ImageIcon("fondobuscador.png");
        decorativeLabel = new JLabel(decorativeImage);
        panel.add(decorativeLabel);

        buscarButton.addActionListener(e -> {
            String palabraClave = textField.getText().toLowerCase();
            if (imagenes.containsKey(palabraClave)) {
                String rutaImagen = imagenes.get(palabraClave);
                try {
                    BufferedImage image = ImageIO.read(new File(rutaImagen));
                    ImageIcon icon = new ImageIcon(image);
                    JLabel imagenLabel = new JLabel(icon);
                    imagePanel.removeAll();
                    imagePanel.add(imagenLabel);
                    panel.remove(decorativeLabel);
                    revalidate();
                    repaint();
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al cargar la imagen.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Imagen no encontrada para la palabra clave ingresada.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        comentarButton.addActionListener(e -> {
            String comentario = commentArea.getText();
            if (!comentario.isEmpty()) {
                try (PrintWriter writer = new PrintWriter(new FileWriter(comentariosFile, true))) {
                    writer.println(comentario);
                    JOptionPane.showMessageDialog(this, "Comentario guardado correctamente.");
                    commentArea.setText("");
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al guardar el comentario.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "El comentario está vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(panel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.WEST);
        mainPanel.add(imagePanel, BorderLayout.CENTER);

        add(mainPanel);
    }

    public static void main(String[] args) {
        Map<String, String> imagenes = new HashMap<>();
        imagenes.put("matematicas", "ruta_imagen_matematicas.JPG");
        imagenes.put("historia", "ruta_imagen_historia.JPG");
        imagenes.put("ciencias", "ruta_imagen_ciencias.JPG");
        imagenes.put("geografia", "ruta_imagen_geografia.JPG");

        SwingUtilities.invokeLater(() -> {
            new BuscarYcomentarImagen (imagenes).setVisible(true);
        });
    }
}
