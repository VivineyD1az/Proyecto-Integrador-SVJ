import javax.swing.JOptionPane;
import java.io.*;
public class Usuarios {
    private Avatar avatarSeleccionado;

    public Avatar getAvatarSeleccionado() {
        return avatarSeleccionado;
    }
    public void setAvatarSeleccionado(Avatar avatarSeleccionado) {
        this.avatarSeleccionado = avatarSeleccionado;
    }

    static boolean validarUsuario(String usuario, String password){
        boolean bnd=false;
        String usuarios = leertxt.leer("PI.txt");
        String[] usuarioclave= usuarios.split(";");
        String[] us;

        for (int i = 0; i < usuarioclave.length; i++) {
            us=usuarioclave[i].split(",");
            if (us[0].equals(usuario) && us[1].equals(password)){
                bnd = true;
            }
            }
        return bnd;
    }
}

