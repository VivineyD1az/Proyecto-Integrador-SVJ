import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Registro extends JFrame implements ActionListener {
    private JTextField usuarioField;
    private JPasswordField contraseñaField;
    private JButton botonRegistrar;

    public Registro() {
        setTitle("Registro");

            // Configuración del frame para que ocupe toda la pantalla
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());


        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(Color.WHITE);

            // Panel para el formulario de registro
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(Color.WHITE);

            // Construcción de restricciones para GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);


        JLabel usuarioLabel = new JLabel("Usuario:");
        panelFormulario.add(usuarioLabel, gbc);

        gbc.gridy++;
        usuarioField = new JTextField(15);
        usuarioField.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(usuarioField, gbc);


        gbc.gridy++;
        JLabel contraseñaLabel = new JLabel("Contraseña:");
        panelFormulario.add(contraseñaLabel, gbc);

        gbc.gridy++;
        contraseñaField = new JPasswordField(15);
        contraseñaField.setFont(new Font("Arial", Font.PLAIN, 20));
        panelFormulario.add(contraseñaField, gbc);

            // Botón para continuar
        gbc.gridy++;
        botonRegistrar = new JButton("continuar");
        botonRegistrar.addActionListener(this);
        botonRegistrar.setFont(new Font("Arial", Font.PLAIN, 20));
        panelFormulario.add(botonRegistrar, gbc);


        panelPrincipal.add(panelFormulario, BorderLayout.CENTER);


        JLabel imagenLabel = new JLabel();
        ImageIcon imagenIcono = new ImageIcon("Free Vector2.jpeg");
        Image imagenEscalada = imagenIcono.getImage().getScaledInstance(screenSize.width / 2, screenSize.height, Image.SCALE_SMOOTH);
        ImageIcon imagenEscaladaIcono = new ImageIcon(imagenEscalada);
        imagenLabel.setIcon(imagenEscaladaIcono);panelPrincipal.add(imagenLabel, BorderLayout.EAST);

        add(panelPrincipal);
        setVisible(true);
        }

        public void actionPerformed(ActionEvent e) {
            String usuario = usuarioField.getText();
            String contraseña = new String(contraseñaField.getPassword());

            if (!usuario.isEmpty() && !contraseña.isEmpty()) {
                try {
                    FileWriter fileWriter = new FileWriter("PI.txt", true);
                    BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

                    bufferedWriter.write(usuario + "," + contraseña + ";");

                    // Cierra el BufferedWriter
                    bufferedWriter.close();

                    JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente.");

                    Usuarios usuarioObj = new Usuarios();
                    SwingUtilities.invokeLater(() -> new interfazAvatar(usuarioObj));

                    // Cierra esta ventana después de registrar
                    dispose();
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Error al guardar el usuario y contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese un usuario y una contraseña válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
    }
}


