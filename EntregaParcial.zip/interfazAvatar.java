import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
    public class interfazAvatar extends JFrame {
        private Usuarios usuario;
        private JComboBox<Avatar> listaAvatares = new JComboBox<>();
        private JLabel imagenAvatar;
        private JPanel panelBotones;

        public interfazAvatar(Usuarios usuario) {
            this.usuario = usuario;

            List<Avatar> avatares = cargarAvatares();
            for (Avatar avatar : avatares) {
                listaAvatares.addItem(avatar);
            }

            JButton botonAceptar = new JButton("Aceptar");
            JButton botonRegresar = new JButton("Regresar");
            botonRegresar.setEnabled(false);

            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());

            JPanel panelBotones = new JPanel();
            panelBotones.add(listaAvatares);
            panelBotones.add(botonAceptar);
            panelBotones.add(botonRegresar);
            panel.add(panelBotones, BorderLayout.NORTH);

            ImageIcon icono = new ImageIcon("iterfaz_avtar.png");
            imagenAvatar = new JLabel(icono);
            panel.add(imagenAvatar, BorderLayout.CENTER);




            add(panel);

            botonAceptar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Avatar avatarSeleccionado = (Avatar) listaAvatares.getSelectedItem();
                    usuario.setAvatarSeleccionado(avatarSeleccionado);

                    mostrarImagenAvatar(avatarSeleccionado);

                    botonAceptar.setEnabled(false);
                    botonRegresar.setEnabled(true);

                }
            });

            botonRegresar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    imagenAvatar.setIcon(null);
                    botonRegresar.setEnabled(false);
                    botonAceptar.setEnabled(true);
                }
            });

            setTitle("Seleccionar Avatar");
            setSize(400, 400);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        }

        private List<Avatar> cargarAvatares() {
            List<Avatar> avatares = new ArrayList<>();
            File carpetaAvatares = new File("C:\\Proyecto1\\Parcial\\imagenes");
            if (carpetaAvatares.isDirectory()) {
                File[] archivos = carpetaAvatares.listFiles();
                for (File archivo : archivos) {
                    if (archivo.isFile()) {
                        avatares.add(new Avatar(archivo.getAbsolutePath()));
                    }
                }
            }
            return avatares;
        }

        private void mostrarImagenAvatar(Avatar avatar) {
            ImageIcon icono = new ImageIcon(avatar.getRutaImagen());
            Image imagen = icono.getImage();
            Image nuevaImagen = imagen.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
            icono = new ImageIcon(nuevaImagen);
            imagenAvatar.setIcon(icono);
        }

        public static void main(String[] args) {
            Usuarios usuario = new Usuarios();
            SwingUtilities.invokeLater(() -> new interfazAvatar(usuario));
        }
    }

