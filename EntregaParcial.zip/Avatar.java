public class Avatar {
    private String rutaImagen;

    public Avatar(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }
    public String getRutaImagen() {
        return rutaImagen;
    }
}
