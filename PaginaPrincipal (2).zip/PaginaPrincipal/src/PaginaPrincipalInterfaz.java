import javax.swing.*;
import java.awt.*;

public class PaginaPrincipalInterfaz extends JFrame {

    public PaginaPrincipalInterfaz() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar al abrir
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Acción al cerrar la ventana
        getContentPane().setBackground(Color.WHITE); // Fondo blanco
        setLayout(new BorderLayout());

        // Crear panel para los botones personalizados
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(Color.WHITE);
        JButton boton1 = new JButton("Iniciar Sesión");
        boton1.addActionListener(e -> {
            InterfazLogin login = new InterfazLogin();
            login.setVisible(true);
        });

        JButton boton2 = new JButton("Registrarse");
        boton2.addActionListener(e -> {
            Registro ventanaRegistro = new Registro();
        });
        JButton boton3 = new JButton("Explorar");
        JButton boton4 = new JButton("Acerca de");
        boton1.setForeground(Color.GRAY); // Texto gris
        boton2.setForeground(Color.GRAY);
        boton3.setForeground(Color.GRAY);
        boton4.setForeground(Color.GRAY);
        boton1.setBorderPainted(false); // Quitar borde del botón
        boton2.setBorderPainted(false);
        boton3.setBorderPainted(false);
        boton4.setBorderPainted(false);
        boton1.setBackground(Color.WHITE); // Fondo blanco
        boton2.setBackground(Color.WHITE);
        boton3.setBackground(Color.WHITE);
        boton4.setBackground(Color.WHITE);
        panelBotones.add(boton1);
        panelBotones.add(boton2);
        panelBotones.add(boton3);
        panelBotones.add(boton4);

        // Agregar panel de botones personalizados al norte del frame
        add(panelBotones, BorderLayout.NORTH);

        // Crear panel izquierdo para los títulos y botón "Empieza ya"
        JPanel panelIzquierdo = new JPanel(new GridBagLayout());
        panelIzquierdo.setBackground(Color.WHITE);

        // Configurar restricciones del GridBagLayout para eliminar los espacios entre los componentes
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 0, 0); // Sin espacio entre componentes

        // Crear panel para el título
        JLabel titulo = new JLabel("Aprendizaje Visual");
        titulo.setFont(new Font("Arial", Font.BOLD, 48)); // Tamaño grande para el título
        titulo.setHorizontalAlignment(SwingConstants.CENTER); // Centrar el texto
        panelIzquierdo.add(titulo, gbc);

        // Crear panel para el subtítulo
        JLabel subtitulo = new JLabel("Descubre herramientas de aprendizaje visual que te ayudarán a aprender mejor y más rápido.");
        panelIzquierdo.add(subtitulo, gbc);

        // Crear panel para el botón "Empieza ya"
        JButton botonExplorar = new JButton("Empieza ya");
        botonExplorar.setForeground(Color.WHITE); // Letras blancas
        botonExplorar.setBackground(Color.YELLOW); // Fondo amarillo
        botonExplorar.setBorderPainted(false); // Quitar borde del botón
        botonExplorar.setFocusPainted(false); // Quitar efecto de enfoque
        botonExplorar.setPreferredSize(new Dimension(100, 30)); // Tamaño cuadrado y chiquito
        panelIzquierdo.add(botonExplorar, gbc);

        // Agregar panel izquierdo al centro del frame
        add(panelIzquierdo, BorderLayout.CENTER);

        // Crear panel para la imagen
        JPanel panelImagen = new JPanel();
        panelImagen.setBackground(Color.WHITE);
        ImageIcon imagen = new ImageIcon("Vector Gratis.png"); // Cambiar por la ruta de la imagen
        JLabel etiquetaImagen = new JLabel(imagen);
        panelImagen.add(etiquetaImagen);

        // Agregar panel de la imagen al este del frame
        add(panelImagen, BorderLayout.EAST);

        // Hacer visible la interfaz
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaginaPrincipalInterfaz::new);
    }
}
