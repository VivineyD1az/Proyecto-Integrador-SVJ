import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InterfazLogin extends JFrame implements ActionListener {

    public JTextField usuarioField;
    public JPasswordField contraseñaField;
    private JButton botonLogin;

    public InterfazLogin() {
        // Título de la ventana
        setTitle("Inicio de Sesión");

        // Configuración del frame para que ocupe toda la pantalla
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar al abrir
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Acción al cerrar la ventana
        getContentPane().setBackground(Color.WHITE); // Fondo blanco
        setLayout(new BorderLayout());

        // Panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(Color.WHITE);

        // Panel para el formulario de inicio de sesión
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(Color.WHITE);

        // Construcción de restricciones para GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Espaciado entre componentes

        // Etiqueta y campo de texto para el usuario
        JLabel usuarioLabel = new JLabel("Usuario:");
        panelFormulario.add(usuarioLabel, gbc);

        gbc.gridy++;
        usuarioField = new JTextField(15);
        usuarioField.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(usuarioField, gbc);

        // Etiqueta y campo de contraseña
        gbc.gridy++;
        JLabel contraseñaLabel = new JLabel("Contraseña:");
        panelFormulario.add(contraseñaLabel, gbc);

        gbc.gridy++;
        contraseñaField = new JPasswordField(15);
        contraseñaField.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(contraseñaField, gbc);

        // Botón de inicio de sesión
        gbc.gridy++;
        botonLogin = new JButton("Iniciar Sesión");
        botonLogin.addActionListener(this);
        botonLogin.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(botonLogin, gbc);

        // Agregar panel del formulario al panel principal
        panelPrincipal.add(panelFormulario, BorderLayout.CENTER);

        // Imagen de fondo
        JLabel imagenLabel = new JLabel();
        ImageIcon imagenIcono = new ImageIcon("foto2.jpg");
        Image imagenEscalada = imagenIcono.getImage().getScaledInstance(screenSize.width / 2, screenSize.height, Image.SCALE_SMOOTH);
        ImageIcon imagenEscaladaIcono = new ImageIcon(imagenEscalada);
        imagenLabel.setIcon(imagenEscaladaIcono);
        panelPrincipal.add(imagenLabel, BorderLayout.EAST);

        // Agregar el panel principal a la ventana
        add(panelPrincipal);
    }

    public void actionPerformed(ActionEvent e) {
        String usuario = usuarioField.getText();
        String contraseña = new String(contraseñaField.getPassword());

        if (Usuarios.validarUsuario(usuario, contraseña)) {
            inicioAdmin ventanaMensaje = new inicioAdmin("Inicio de sesión exitoso", usuario, this);
            ventanaMensaje.setVisible(true);
            inicioAdmin.saludar(usuario);
            this.dispose();
        } else {
            inicioAdmin ventanaMensaje = new inicioAdmin("Usuario o contraseña incorrectos", "", this);
            ventanaMensaje.setVisible(true);
        }
    }
}
