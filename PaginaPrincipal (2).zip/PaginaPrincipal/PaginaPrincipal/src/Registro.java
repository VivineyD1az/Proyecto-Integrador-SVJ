import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class Registro extends JFrame implements ActionListener {
    private JTextField usuarioField;
    private JPasswordField contraseñaField;
    private JButton botonRegistrar;

    public Registro() {
        // Título de la ventana
        setTitle("Registro");

        // Configuración del frame para que ocupe toda la pantalla
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar al abrir
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cierra solo esta ventana al cerrarla
        getContentPane().setBackground(Color.WHITE); // Fondo blanco
        setLayout(new BorderLayout());

        // Panel principal
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBackground(Color.WHITE);

        // Panel para el formulario de registro
        JPanel panelFormulario = new JPanel(new GridBagLayout());
        panelFormulario.setBackground(Color.WHITE);

        // Construcción de restricciones para GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Espaciado entre componentes

        // Etiqueta y campo de texto para el usuario
        JLabel usuarioLabel = new JLabel("Usuario:");
        panelFormulario.add(usuarioLabel, gbc);

        gbc.gridy++;
        usuarioField = new JTextField(15);
        usuarioField.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(usuarioField, gbc);

        // Etiqueta y campo de contraseña
        gbc.gridy++;
        JLabel contraseñaLabel = new JLabel("Contraseña:");
        panelFormulario.add(contraseñaLabel, gbc);

        gbc.gridy++;
        contraseñaField = new JPasswordField(15);
        contraseñaField.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(contraseñaField, gbc);

        // Botón de registrar
        gbc.gridy++;
        botonRegistrar = new JButton("Registrar");
        botonRegistrar.addActionListener(this);
        botonRegistrar.setFont(new Font("Arial", Font.PLAIN, 20)); // Aumenta el tamaño del texto
        panelFormulario.add(botonRegistrar, gbc);

        // Agregar panel del formulario al panel principal
        panelPrincipal.add(panelFormulario, BorderLayout.CENTER);

        // Imagen de fondo
        JLabel imagenLabel = new JLabel();
        ImageIcon imagenIcono = new ImageIcon("Free Vector2.jpeg");
        Image imagenEscalada = imagenIcono.getImage().getScaledInstance(screenSize.width / 2, screenSize.height, Image.SCALE_SMOOTH);
        ImageIcon imagenEscaladaIcono = new ImageIcon(imagenEscalada);
        imagenLabel.setIcon(imagenEscaladaIcono);
        panelPrincipal.add(imagenLabel, BorderLayout.EAST);

        // Agregar el panel principal a la ventana
        add(panelPrincipal);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String usuario = usuarioField.getText();
        String contraseña = new String(contraseñaField.getPassword());

        if (!usuario.isEmpty() && !contraseña.isEmpty()) {
            try {
                // Abre el archivo para escritura y crea un objeto BufferedWriter
                FileWriter fileWriter = new FileWriter("PI.txt", true);
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

                // Escribe el usuario y la contraseña seguidos de una coma
                bufferedWriter.write(usuario + "," + contraseña + ";");

                // Cierra el BufferedWriter
                bufferedWriter.close();

                // Muestra un mensaje de registro exitoso
                JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente.");

                // Cierra esta ventana después de registrar
                dispose();
            } catch (IOException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error al guardar el usuario y contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese un usuario y una contraseña válidos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
