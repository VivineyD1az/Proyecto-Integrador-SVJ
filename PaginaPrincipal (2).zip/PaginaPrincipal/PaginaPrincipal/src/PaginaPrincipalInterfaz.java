import javax.swing.*;
import java.awt.*;

public class PaginaPrincipalInterfaz extends JFrame {

    public PaginaPrincipalInterfaz() {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Maximizar al abrir
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Acción al cerrar la ventana
        getContentPane().setBackground(Color.WHITE); // Fondo blanco
        setLayout(new BorderLayout());

        // Crear panel superior para los botones personalizados
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(Color.WHITE);
        JButton boton1 = new JButton("Iniciar Sesión");
        boton1.addActionListener(e -> {
            InterfazLogin login = new InterfazLogin();
            login.setVisible(true);
        });

        JButton boton2 = new JButton("Registrarse");
        boton2.addActionListener(e -> {
            Registro ventanaRegistro = new Registro();
        });
        JButton boton3 = new JButton("Explorar");
        JButton boton4 = new JButton("Acerca de");
        boton1.setForeground(Color.GRAY); // Texto gris
        boton2.setForeground(Color.GRAY);
        boton3.setForeground(Color.GRAY);
        boton4.setForeground(Color.GRAY);
        boton1.setBorderPainted(false); // Quitar borde del botón
        boton2.setBorderPainted(false);
        boton3.setBorderPainted(false);
        boton4.setBorderPainted(false);
        boton1.setBackground(Color.WHITE); // Fondo blanco
        boton2.setBackground(Color.WHITE);
        boton3.setBackground(Color.WHITE);
        boton4.setBackground(Color.WHITE);
        panelBotones.add(boton1);
        panelBotones.add(boton2);
        panelBotones.add(boton3);
        panelBotones.add(boton4);

        // Agregar panel de botones personalizados al frame
        add(panelBotones, BorderLayout.NORTH);

        // Crear panel para el título y subtítulo
        JPanel panelTitulo = new JPanel(new GridLayout(2, 1)); // Layout para colocar el título y el subtítulo uno encima del otro
        panelTitulo.setBackground(Color.WHITE);
        JLabel titulo = new JLabel("Aprendizaje Visual");
        titulo.setFont(new Font("Arial", Font.BOLD, 24)); // Tamaño grande para el título
        titulo.setHorizontalAlignment(SwingConstants.CENTER); // Centrar texto
        JLabel subtitulo = new JLabel("Descubre herramientas de aprendizaje visual que te ayudarán a aprender mejor y más rápido.");
        subtitulo.setHorizontalAlignment(SwingConstants.CENTER); // Centrar texto
        panelTitulo.add(titulo);
        panelTitulo.add(subtitulo);

        // Agregar panel del título y subtítulo al centro izquierdo del frame
        panelTitulo.setBounds(50, 100, 300, 50); // Define las coordenadas (x, y) y el tamaño (ancho, alto) del panelBotonExplorar
        add(panelTitulo);

        // Crear panel para el botón "Explorar"
        JPanel panelBotonExplorar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotonExplorar.setBackground(Color.WHITE);
        JButton botonExplorar = new JButton("Empieza ya ");
        botonExplorar.setForeground(Color.WHITE); // Letras blancas
        botonExplorar.setBackground(Color.YELLOW); // Fondo amarillo
        botonExplorar.setBorderPainted(false); // Quitar borde del botón
        botonExplorar.setFocusPainted(false); // Quitar efecto de enfoque
        botonExplorar.setFont(new Font("Arial", Font.BOLD, 16)); // Tamaño grande para el texto
        panelBotonExplorar.add(botonExplorar);

        // Agregar panel del botón "Explorar" al sur del frame
        panelBotonExplorar.setBounds(1, 100, 200, 50); // Define las coordenadas (x, y) y el tamaño (ancho, alto) del panelBotonExplorar
        add(panelBotonExplorar);

        JPanel panelImagen = new JPanel();
        panelImagen.setBackground(Color.WHITE);
        ImageIcon imagen = new ImageIcon("Vector Gratis.png"); // Cambiar por la ruta de la imagen
        JLabel etiquetaImagen = new JLabel(imagen);
        panelImagen.add(etiquetaImagen);

        // Agregar panel de la imagen al este del frame
        add(panelImagen, BorderLayout.EAST);

        // Hacer visible la interfaz
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaginaPrincipalInterfaz::new);
    }
}
